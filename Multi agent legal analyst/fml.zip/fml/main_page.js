// Redirect to the Google Colab link on button click
document.getElementById("uploadButton").addEventListener("click", function () {
    window.location.href = "https://colab.research.google.com/drive/1PN_O0CfLuSQYObjbkt9ZLrJ3wzZJb5mt";
});
