// Handle the login process
document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent form from submitting normally

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (username && password) {
        alert("Login successful!");
        window.location.href = "main_page.html"; // Redirect to the main page
    } else {
        alert("Please enter both username and password.");
    }
});
